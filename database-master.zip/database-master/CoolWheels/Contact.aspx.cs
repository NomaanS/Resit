﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CoolWheels
{
    public partial class Contact : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Add any page-specific logic here
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            // Handle the form submission here (send email, save to database, etc.)
            // You can add your own logic to process the user's input
        }
    }
}
